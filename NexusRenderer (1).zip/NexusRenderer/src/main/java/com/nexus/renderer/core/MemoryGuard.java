package com.nexus.renderer.core;

import com.nexus.renderer.NexusRenderer;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

/** Libera caches proprios ao sair de um mundo, evitando acumulo de memoria. */
public final class MemoryGuard {
    private static final List<Runnable> CLEANERS = new ArrayList<>();

    private MemoryGuard() {}

    public static synchronized void addCleaner(Runnable r) {
        CLEANERS.add(r);
    }

    public static void register() {
        try {
            ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> clean());
        } catch (Throwable t) {
            NexusRenderer.LOGGER.warn("Evento de desconexao indisponivel: {}", t.toString());
        }
    }

    public static synchronized void clean() {
        for (Runnable r : CLEANERS) {
            try {
                r.run();
            } catch (Throwable t) {
                NexusRenderer.LOGGER.warn("Falha ao limpar cache", t);
            }
        }
    }
}
