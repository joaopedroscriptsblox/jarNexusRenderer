package com.nexus.renderer;

import com.nexus.renderer.core.NexusThreads;
import com.nexus.renderer.core.MemoryGuard;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NexusRenderer implements ModInitializer {
    public static final String MOD_ID = "nexusrenderer";
    public static final Logger LOGGER = LoggerFactory.getLogger("Nexus Renderer");

    @Override
    public void onInitialize() {
        NexusThreads.start();
        MemoryGuard.register();
        LOGGER.info("Nexus Renderer iniciado com {} threads de trabalho", NexusThreads.size());
    }
}
