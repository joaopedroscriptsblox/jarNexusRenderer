package com.nexus.renderer.core;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/** Pool de threads da CPU usado para preparar dados de chunks fora da thread principal. */
public final class NexusThreads {
    private static ExecutorService pool;
    private static int size;

    private NexusThreads() {}

    public static synchronized void start() {
        if (pool != null) return;
        size = Math.max(1, Runtime.getRuntime().availableProcessors() - 1);
        AtomicInteger id = new AtomicInteger();
        pool = Executors.newFixedThreadPool(size, r -> {
            Thread t = new Thread(r, "Nexus-Worker-" + id.incrementAndGet());
            t.setDaemon(true);
            t.setPriority(Thread.NORM_PRIORITY - 1);
            return t;
        });
    }

    public static int size() {
        return size;
    }

    public static void submit(Runnable task) {
        if (pool == null) start();
        pool.execute(task);
    }

    /** Divide [0, total) em blocos e roda em paralelo, esperando todos terminarem. */
    public static void parallelFor(int total, java.util.function.IntConsumer body) {
        if (pool == null) start();
        int parts = Math.min(size, Math.max(1, total));
        java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(parts);
        int step = (total + parts - 1) / parts;
        for (int p = 0; p < parts; p++) {
            final int from = p * step;
            final int to = Math.min(total, from + step);
            pool.execute(() -> {
                try {
                    for (int i = from; i < to; i++) body.accept(i);
                } finally {
                    latch.countDown();
                }
            });
        }
        try {
            latch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
