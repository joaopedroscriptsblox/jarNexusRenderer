package com.nexus.renderer.mixin;

import net.minecraft.world.entity.Mob;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * IA de mobs otimizada: mobs longe de qualquer jogador pensam menos vezes por segundo.
 * Mobs com alvo ou proximos continuam com IA completa.
 */
@Mixin(Mob.class)
public abstract class MobAiThrottleMixin {
    private static final double FAR_SQ = 48.0 * 48.0;
    private static final double VERY_FAR_SQ = 96.0 * 96.0;

    @Inject(method = "serverAiStep", at = @At("HEAD"), cancellable = true, require = 0)
    private void nexus$throttleAi(CallbackInfo ci) {
        Mob self = (Mob) (Object) this;
        if (self.getTarget() != null) return;

        var player = self.level().getNearestPlayer(self, VERY_FAR_SQ);
        double distSq = player == null ? Double.MAX_VALUE : player.distanceToSqr(self);

        int interval;
        if (distSq > VERY_FAR_SQ) interval = 8;
        else if (distSq > FAR_SQ) interval = 4;
        else return;

        if ((self.tickCount + self.getId()) % interval != 0) ci.cancel();
    }
}
