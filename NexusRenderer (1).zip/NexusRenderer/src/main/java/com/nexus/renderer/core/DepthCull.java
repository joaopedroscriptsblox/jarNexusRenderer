package com.nexus.renderer.core;

/**
 * Regra de corte vertical: nao gera/renderiza secoes muito abaixo do jogador.
 * Se o jogador chegar perto do limite inferior da renderizacao, as secoes voltam a ser renderizadas.
 */
public final class DepthCull {
    public static final int CULL_BELOW = 30;       // blocos abaixo do jogador que ficam sem renderizar
    public static final int REVEAL_DISTANCE = 10;  // distancia do limite em que volta a renderizar

    private DepthCull() {}

    /**
     * @param sectionTopY  Y do topo da secao (16x16x16)
     * @param playerY      Y do jogador
     * @param worldMinY    Y minimo do mundo
     * @return true se a secao pode ser ignorada
     */
    public static boolean shouldSkip(int sectionTopY, int playerY, int worldMinY) {
        int limitY = playerY - CULL_BELOW;
        // Chegou a 10 blocos do limite inferior do mundo: renderiza normalmente.
        if (playerY - worldMinY <= CULL_BELOW + REVEAL_DISTANCE) return false;
        return sectionTopY < limitY;
    }
}
